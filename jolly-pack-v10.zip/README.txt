Jolly resource pack (v9) - merged jolly-pack-v8 + jolly-items add-on.

Contents
- 3D Santa hat, pom pom tint = tier color (assets/jolly/items/santa_hat_<tier>.json).
- Jolly Voucher item model (jolly:jolly_voucher)           <- from the items add-on
- Gift and Sleigh models (jolly:gift, jolly:sleigh)        <- from the items add-on
- Jolly Coin / Jolly Bill retextures (name-matched, see below)

Jolly Coin / Jolly Bill retextures
- Items renamed JOLLY COIN (alternating red/green bold) show a candy cane; JOLLY BILL shows the red-banded bill with a bell.
- Works by matching the item's custom name, on the base items listed in assets/minecraft/items/.
- Requires a client on 1.21.5+ (uses the "minecraft:component" select property).
- The Jolly plugin (3.9+) gives exactly these items: /jolly item coin, gift rewards, /diamondtocoin and /diamondtobill.
- The add-on's own jolly_coin model/texture was removed on purpose: this pack's coin is the one used.

pack.mcmeta uses min_format 94 / max_format 999; if the client shows a version warning, set min_format to your version's value.

v10: Sleigh boat
- assets/minecraft/textures/entity/boat/pale_oak.png repaints the Pale Oak Boat as a red-and-gold sleigh (128x64, vanilla boat layout).
- It applies to EVERY pale oak boat for anyone using this pack. Use with the Jolly plugin's cosmetics.sleigh.boat-type: PALE_OAK_BOAT,
  which stops the floating sleigh model and removes the pale oak boat crafting recipes so players can't make them.
