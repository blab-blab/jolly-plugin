Jolly resource pack (v9) - merged jolly-pack-v8 + jolly-items add-on.

Contents
- 3D Santa hat, pom pom tint = tier color (assets/jolly/items/santa_hat_<tier>.json).
- Jolly Voucher item model (jolly:jolly_voucher)           <- from the items add-on
- Gift and Sleigh models (jolly:gift, jolly:sleigh)        <- from the items add-on
- Jolly Coin / Jolly Bill retextures (name-matched, see below)

Jolly Coin / Jolly Bill retextures
- Items renamed JOLLY COIN (alternating red/green bold) show a candy cane; JOLLY BILL shows the red-banded bill with a bell.
- Works by matching the item's custom name, on the base items listed in assets/minecraft/items/.
- Requires a client on 1.21.5+ (uses the "minecraft:component" select property).
- The Jolly plugin (3.9+) gives exactly these items: /jolly item coin, gift rewards, /diamondtocoin and /diamondtobill.
- The add-on's own jolly_coin model/texture was removed on purpose: this pack's coin is the one used.

pack.mcmeta uses min_format 94 / max_format 999; if the client shows a version warning, set min_format to your version's value.

v10: Sleigh boat
- assets/minecraft/textures/entity/boat/pale_oak.png repaints the Pale Oak Boat as a red-and-gold sleigh (128x64, vanilla boat layout).
- It applies to EVERY pale oak boat for anyone using this pack. Use with the Jolly plugin's cosmetics.sleigh.boat-type: PALE_OAK_BOAT,
  which stops the floating sleigh model and removes the pale oak boat crafting recipes so players can't make them.

v11: Gift Box + Sleigh
- jolly:gift_box / jolly:gift_bow item models: 3D red box with gold ribbons and a bow (the Gift Box item and the bow shown on placed boxes).
- assets/minecraft/textures/entity/shulker/shulker_red.png repaints RED shulker boxes as the gift box (ALL red shulker boxes look like gifts with this pack).
- assets/minecraft/textures/entity/boat/pale_oak.png is now fully TRANSPARENT: the plugin swaps a boat to Pale Oak only while Santa rides it, and the
  3D jolly:sleigh model follows Santa instead. Anyone not riding as Santa never sees a pale oak boat.

v12: chest boat pale oak texture also transparent.

v13: Sled textures
- jolly:sled_item = the sled's inventory icon (applied to the Sled item by the Jolly plugin 4.8+ when items.use-resource-pack is true).
- jolly:sled_wood / sled_runner / sled_dark / sled_red / sled_white / sled_lamp = the textured cubes the in-world sled is built from.
  Textures: assets/jolly/textures/item/sled_*.png (16x16, edit freely).

v14: merged with ChristmasPack_26_3 (Futureazoo) + decor items
- Christmas pack: all textures/models/OptiFine files EXCEPT anything shulker-related. The red shulker stays the Jolly gift box;
  the other shulker colours and the shulker box item stay vanilla. Iron bars are string lights (Christmas pack models).
  OptiFine-only parts (CTM, random entities, CEM, emissive) only show with OptiFine/compatible mods. Extra credits: credits.txt.
- New item models, namespace jolly (assets/jolly/items/<id>.json -> models/item/decor/<id>.json). Give one with:
    /give @s minecraft:paper[item_model="jolly:wreath"]
  or use the JollyDecor datapack for right-click placing (see DECOR_COMMANDS.txt).
- Flat/wall: wreath, paper_star, stocking, mistletoe, snowflake, candy_cane, big_bow, gingerbread_man, garland, string_lights, icicles,
  reindeer_lights, advent_calendar
- Trees: xmas_tree (snow + candles), xmas_tree_lights, xmas_tree_white, xmas_tree_mini
- Figures/tabletop: snowman, nutcracker, reindeer, present_red/green/blue/gold, present_stack, present_giant, candle_set, poinsettia, luminaria,
  cookie_plate, snow_globe, gingerbread_house, snow_pile, ornament_red/gold/blue/silver, ornament_cluster
- Small leaves (spruce leaf texture squeezed onto smaller cubes): leaves_small (8px), leaves_mini (4px), leaves_tiny_row, leaves_slab, leaves_layer,
  leaves_lights, leaves_snowy_slab, leaves_small_snowy, leaves_tree_small
- Big Christmas lantern with its own 32x32 texture (assets/jolly/textures/item/decor/big_lantern.png): big_lantern, big_lantern_hanging, lamp_post
- Most decor uses one shared colour palette texture (textures/item/decor/palette.png); edit its cells to recolour.

v17: Jolly Saber
- jolly:jolly_saber item model + assets/jolly/textures/item/jolly_saber.png (16x16 candy-cane Christmas sword, edit freely).
- The Jolly plugin (5.0.1 build 4+) gives the saber (craft 1 Jolly Saber Shard + any sword) with item model jolly:jolly_saber.
