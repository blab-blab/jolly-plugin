Jolly resource pack. 3D Santa hat (from your christmas-hat model); pom pom tint = tier color.
pack.mcmeta uses min_format 94 / max_format 999; if the client shows a version warning, set min_format to your version's value.

Jolly Coin / Jolly Bill retextures
- Items renamed JOLLY COIN (alternating &c&l / &2&l) show a candy cane; JOLLY BILL shows the red-banded bill with a bell.
- Works by matching the item's custom name, on the base items listed in assets/minecraft/items/.
- Requires a client on 1.21.5+ (uses the "minecraft:component" select property).
