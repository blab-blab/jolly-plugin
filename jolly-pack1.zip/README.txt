Jolly resource pack. 3D Santa hat (from your christmas-hat model); pom pom tint = tier color.
pack.mcmeta uses min_format 94 / max_format 999; if the client shows a version warning, set min_format to your version's value.
