Jolly resource pack. Hat model, textures and pack are original (no third-party assets).
pack.mcmeta uses min_format 94 / max_format 999; if the client shows a version warning, set min_format to your version's value.
